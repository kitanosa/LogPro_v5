﻿# LP_Lab3
## Решение задач методом поиска в пространстве состояний

Условие лабораторной работы смотрите [здесь](http://www.soshnikov.com/courses/prolog/labs/lab3.pdf).


