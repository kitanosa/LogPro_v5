﻿# LP_Lab4
## Обработка естественного языка

Условие лабораторной работы смотрите [здесь](http://www.soshnikov.com/courses/prolog/labs/lab4.pdf).


